﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject[] hazards;
    public GameObject background;
    public GameObject starfield;
    public Vector3 spawnValues;
    public int hazardCount;
    public float spawnWait;
    public float startWait;
    public float waveWait;
    public AudioSource musicSource;
    public AudioClip musicClipOne;
    public AudioClip musicClipTwo;
    public AudioClip musicClipThree;

    public Text ScoreText;
    public Text restartText;
    public Text gameOverText;
    public Text waveCounter;

    private bool gameOver;
    private bool restart;
    private int score;
    private int wave;
    private BGController bg;
    private bool HardMode;
    private bool Survival;
    private float fast=5;

    void Start()
    {
        bg = background.GetComponent<BGController>();
        gameOver=false;
        restart=false;
        Survival=false;
        HardMode=false;
        restartText.text = "";
        gameOverText.text = "";
        score = 0;
        wave= 1;
        waveCounter.text = "Wave: " + wave;
        UpdateScore();
        StartCoroutine(SpawnWaves());
        musicSource.clip = musicClipOne;
        musicSource.Play();
    }

    void Update()
    {
        if (restart)
        {
            if (Input.GetKeyDown (KeyCode.Y))
            {
                SceneManager.LoadScene("Space Shooter");
            }
        }
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
        if(Input.GetKeyDown(KeyCode.E))
        {
            Survival=true;
        }
        if(Input.GetKeyDown(KeyCode.X))
        {
            HardMode=true;
        }
    }

    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startWait);
        while (true)
        {
            for (int i = 0; i < hazardCount; i++)
            {
                GameObject hazard = hazards [Random.Range (1, hazards.Length)];
                Vector3 spawnPosition = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                Quaternion spawnRotation = Quaternion.identity;
                Instantiate(hazard, spawnPosition, spawnRotation);
                Mover move = hazard.GetComponent<Mover>();
                move.speed=-fast;
                if(HardMode==true)
                {
                    move.speed=-fast*2;
                }
                yield return new WaitForSeconds(spawnWait);
            }
            yield return new WaitForSeconds(waveWait);
            if (gameOver)
            {
                restartText.text = "Press 'Y' to Restart!";
                restart=true;
                break;
            }
            wave=wave+1;
            waveCounter.text = "Wave: " + wave;
            if(Survival==true)
            {
                fast = fast+1;
            }
        }
    }

    public void AddScore(int newScoreValue)
    {
        score += newScoreValue;
        UpdateScore();
    }

    void UpdateScore()
    {
        ScoreText.text = "Points: " + score;
        if (score >= 100 && Survival==false)
          {
              if(musicSource.clip != musicClipTwo)
              {
                musicSource.Stop();
                musicSource.clip = musicClipTwo;
                musicSource.Play();
              }
            gameOverText.text = "You win! Game Created By Tonnie Hovanec, Credits to Reachgrounds' `Now You're a Hero`";
            gameOver = true;
            restart = true;
            bg.scrollSpeed = -10.0f;
            Rigidbody star=starfield.GetComponent<Rigidbody>();
            star.velocity=transform.forward*-3;
           }
    }

    public void GameOver()
    {
        musicSource.Stop();
        musicSource.clip = musicClipThree;
        musicSource.Play();
        gameOverText.text = "Game Over! Credits to Kistol's `Game Over III`.";
        gameOver = true;
    }
}
